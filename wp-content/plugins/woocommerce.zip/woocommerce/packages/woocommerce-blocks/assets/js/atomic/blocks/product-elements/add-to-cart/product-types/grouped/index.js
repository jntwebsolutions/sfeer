/**
 * Internal dependencies
 */
import GroupList from './group-list';

/**
 * Grouped Product Add To Cart Form
 */
const Grouped = () => {
	return <GroupList />;
};

export default Grouped;
