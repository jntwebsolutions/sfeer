/**
 * Identifier key for this store reducer.
 *
 * @type {string}
 */
export const STORE_KEY = 'wc/store/schema';
